package com.springrest.springrest.models;

import java.sql.Date;

import jakarta.persistence.Table;

@jakarta.persistence.Entity
@Table(name = "customerdetails")
public class CustomerDetails {
    @jakarta.persistence.Id
    @jakarta.persistence.GeneratedValue(strategy = jakarta.persistence.GenerationType.IDENTITY)
    private Long id;
    private String name;
    @jakarta.persistence.Column(unique = true)
    private String email;
    private Date dob;
    private String occupation;
    private String customerGroup;

    // Constructor
    public CustomerDetails() {
        // Default constructor
    }

    // Parameterized constructor
    public CustomerDetails(String name, String email, Date dob, String occupation) {
        this.name = name;
        this.email = email;
        this.dob = dob;
        this.occupation = occupation;

        // Additional logic for initializing other fields or applying business rules
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public String getCustomerGroup() {
        return customerGroup;
    }

    public void setCustomerGroup(String customerGroup) {
        this.customerGroup = customerGroup;
    }
}

