package com.springrest.springrest.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springrest.springrest.CustomerDetailsApplication;
import com.springrest.springrest.models.CustomerDetails;

public interface CustomerDetailsRepository extends JpaRepository<CustomerDetailsApplication, Long> {

	CustomerDetails save(CustomerDetails customerDetails);


	
   
}
