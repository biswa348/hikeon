package com.springrest.springrest.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springrest.springrest.models.CustomerDetails;
import com.springrest.springrest.repository.CustomerDetailsRepository;

import java.util.Calendar;

@Service
public class CustomerDetailsService {

    @Autowired
    private CustomerDetailsRepository customerRepository;

    public void createCustomer(CustomerDetails customerDetails) {
        validateCustomerDetails(customerDetails);
        customerRepository.save(customerDetails);
    }

    private void validateCustomerDetails(CustomerDetails customerDetails) {
        // Validation logic for age
        Calendar dob = Calendar.getInstance();
        dob.setTime(customerDetails.getDob());
        Calendar today = Calendar.getInstance();
        today.add(Calendar.YEAR, -18);

        if (dob.after(today)) {
            throw new IllegalArgumentException("Customer must be 18 years or older.");
        }

    }

	 static CustomerDetails updateCustomer(Long id, CustomerDetails customerDetails) {
		// TODO Auto-generated method stub
		return null;
	}

	public static void deleteCustomer(Long id) {
		// TODO Auto-generated method stub
		
	}

	public static CustomerDetails getCustomerById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	
	}

  


