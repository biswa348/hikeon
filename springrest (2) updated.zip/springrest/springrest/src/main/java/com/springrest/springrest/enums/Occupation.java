package com.springrest.springrest.enums;

public enum Occupation {

}
