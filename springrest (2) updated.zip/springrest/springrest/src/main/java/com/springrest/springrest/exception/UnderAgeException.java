package com.springrest.springrest.exception;

@SuppressWarnings("serial")
public class UnderAgeException extends Exception {

    // Constructors
    public UnderAgeException() {
        super("Person is underage.");
    }

    public UnderAgeException(String message) {
        super(message);
    }
    
}

